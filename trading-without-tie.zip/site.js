// Static links work without JavaScript. This file adds only menu/guide interactions.
const picker = document.querySelector('.language-picker');
if (picker) {
  const trigger = picker.querySelector('summary');
  picker.addEventListener('pointerleave', e => { if (e.pointerType === 'mouse') picker.open = false; });
  document.addEventListener('pointerdown', e => { if (!picker.contains(e.target)) picker.open = false; });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && picker.open) { picker.open = false; trigger.focus(); } });
  picker.addEventListener('focusout', e => { if (!picker.contains(e.relatedTarget)) picker.open = false; });
  picker.querySelectorAll('a').forEach(a => { if (/^#(?:step[123]|faq)$/.test(location.hash)) a.hash = location.hash; });
}
const notice = document.querySelector('#link-notice');
if (notice) {
  document.querySelectorAll('[data-notice]').forEach(b => b.addEventListener('click', () => notice.showModal()));
  notice.querySelectorAll('button').forEach(b => b.addEventListener('click', () => notice.close()));
  notice.addEventListener('click', e => { const r = notice.getBoundingClientRect(); if (e.target === notice && (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom)) notice.close(); });
}
const stepBoxes = [...document.querySelectorAll('[data-step]')];
if (stepBoxes.length) {
  const storageKey = 'vladimir-copy-guide-v1';
  let completed = [];
  try { const value = JSON.parse(sessionStorage.getItem(storageKey) || '[]'); if (Array.isArray(value)) completed = [...new Set(value.filter(n => [1,2,3].includes(n)))]; } catch (_) {}
  function render() {
    stepBoxes.forEach(b => b.checked = completed.includes(Number(b.dataset.step)));
    const progress = document.querySelector('#guide-progress');
    if (progress) progress.value = completed.length;
    const counter = document.querySelector('#progress-count');
    if (counter) counter.textContent = `${completed.length} / 3`;
    const message = document.querySelector('#completion');
    if (message) message.hidden = completed.length !== 3;
  }
  function save() { try { sessionStorage.setItem(storageKey, JSON.stringify(completed)); } catch (_) {} render(); }
  stepBoxes.forEach(b => b.addEventListener('change', () => {
    const n = Number(b.dataset.step);
    completed = b.checked ? [...new Set([...completed,n])] : completed.filter(i => i !== n);
    save();
    if (b.checked) {
      const next = document.querySelector(`#step${n+1}`);
      if (next) { next.open = true; const current = b.closest('details'); if (current) current.open = false; next.querySelector('summary').focus(); }
    }
  }));
  document.querySelector('#reset-progress')?.addEventListener('click', () => { completed = []; save(); document.querySelectorAll('details.step').forEach((s,i) => s.open = i===0); });
  function openHash() { if (/^#step[123]$/.test(location.hash)) { const step = document.querySelector(location.hash); if (step) step.open = true; } }
  window.addEventListener('hashchange',openHash);openHash();render();
}
