// Static links work without JavaScript. This file adds only menu/guide interactions.
const picker = document.querySelector('.language-picker');
if (picker) {
  const trigger = picker.querySelector('summary');
  picker.addEventListener('pointerleave', e => { if (e.pointerType === 'mouse') picker.open = false; });
  document.addEventListener('pointerdown', e => { if (!picker.contains(e.target)) picker.open = false; });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && picker.open) { picker.open = false; trigger.focus(); } });
  picker.addEventListener('focusout', e => { if (!picker.contains(e.relatedTarget)) picker.open = false; });
  picker.querySelectorAll('a').forEach(a => { if (/^#(?:step[123]|faq)$/.test(location.hash)) a.hash = location.hash; });
}
const notice = document.querySelector('#link-notice');
if (notice) {
  document.querySelectorAll('[data-notice]').forEach(b => b.addEventListener('click', () => notice.showModal()));
  notice.querySelectorAll('button').forEach(b => b.addEventListener('click', () => notice.close()));
  notice.addEventListener('click', e => { const r = notice.getBoundingClientRect(); if (e.target === notice && (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom)) notice.close(); });
}
const stepBoxes = [...document.querySelectorAll('[data-step]')];
if (stepBoxes.length) {
  let completed = 0;
  const steps = [...document.querySelectorAll('.step')];
  function setOpen(step, open) {
    step.classList.toggle('open', open);
    step.querySelector('.step-toggle').setAttribute('aria-expanded', String(open));
    step.querySelector('.step-body').inert = !open;
  }
  function render() {
    steps.forEach((step, index) => {
      const locked = index > completed;
      step.classList.toggle('locked', locked);
      step.classList.toggle('completed', index < completed);
      const box = step.querySelector('[data-step]');
      box.checked = index < completed;
      box.disabled = locked;
      step.querySelector('.step-toggle').disabled = locked;
      if (locked) setOpen(step, false);
    });
    const progress = document.querySelector('#guide-progress');
    progress.setAttribute('aria-valuenow', String(completed));
    document.querySelector('#progressFill').style.width = `${completed / 3 * 100}%`;
    document.querySelector('#progress-count').textContent = `${completed} / 3`;
    document.querySelector('#progressWrapper').classList.toggle('sticky', completed > 0);
    document.querySelector('#completion').hidden = completed !== 3;
    document.querySelector('#completion').classList.toggle('show', completed === 3);
  }
  steps.forEach((step, index) => {
    const toggle = step.querySelector('.step-toggle');
    toggle.addEventListener('click', () => {
      if (index <= completed) setOpen(step, !step.classList.contains('open'));
    });
    step.querySelector('.step-header').addEventListener('click', e => {
      if (!e.target.closest('button,label,input') && index <= completed) setOpen(step, !step.classList.contains('open'));
    });
    step.querySelector('[data-step]').addEventListener('change', e => {
      const checked = e.target.checked;
      // The completed prefix is the sole source of truth: skipped steps cannot be accepted.
      if (index > completed) { render(); return; }
      if (checked) {
        if (index !== completed) { render(); return; }
        completed = index + 1;
        setOpen(step, false);
        if (steps[index + 1]) setOpen(steps[index + 1], true);
      } else {
        completed = index;
        steps.slice(index + 1).forEach(s => setOpen(s, false));
        setOpen(step, true);
      }
      render();
    });
    setOpen(step, index === 0);
  });
  render();
}
const faq = document.querySelector('#faq');
if (faq) {
  const questions = [...faq.querySelectorAll('details')];
  questions.forEach(question => {
    question.open = false;
    question.querySelector('summary').addEventListener('click', e => {
      e.preventDefault();
      const wasOpen = question.open;
      questions.forEach(item => item.open = false);
      question.open = !wasOpen;
    });
  });
  document.addEventListener('click', e => {
    if (!faq.contains(e.target)) questions.forEach(item => item.open = false);
  });
}
const returnLink = document.querySelector('[data-return]');
if (returnLink && document.referrer) {
  try {
    const previous = new URL(document.referrer);
    const ownBase = new URL('.', document.querySelector('script[src*="site.js"]').src);
    // Only follow a real preceding page from this site, never an external referrer.
    const basePath = ownBase.pathname;
    if (previous.origin === location.origin && previous.pathname.startsWith(basePath) && previous.href !== location.href) {
      returnLink.href = previous.href;
      returnLink.addEventListener('click', e => {
        if (e.button === 0 && !e.ctrlKey && !e.metaKey && !e.shiftKey && !e.altKey && history.length > 1) {
          e.preventDefault(); history.back();
        }
      });
    }
  } catch (_) {}
}
